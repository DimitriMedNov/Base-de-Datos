<?php  /// Moodle Configuration File 

$CFG= new stdClass();
$CFG->dbhost = 'localhost';
$CFG->dbname = 'bda_equipo2';
$CFG->dbuser = 'bda_equipo2';
$CFG->dbpass = 'vi?U727Z4vmG';
$CFG->prefix = 'mdl_';
$CFG->wwwroot = 'http://runsoft-mexico.com/bda_equipo2';
$CFG->dataroot = 'http://runsof-mexico.com/bda_equipo2';
$CFG->directorypermissions =00777;
?>