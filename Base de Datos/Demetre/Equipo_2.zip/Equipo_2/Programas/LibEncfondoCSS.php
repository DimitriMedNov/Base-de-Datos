<?php
echo '<style type="text/css">'.	
				'@import url('.$CFG->wwwroot.'/ArchivosCSS/fondo.css);'.	
				'@import url('.'/ArchivosCSS/Enclineas.css);'.	
				'@import url('.'/ArchivosCSS/confventanas.css);'.	
		'</style>';
?>